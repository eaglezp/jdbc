create view V$_DEPT_AVG_SAL_INFO as
  (select t.deptno, avg_sal, grade 
	from (select deptno, avg(sal) avg_sal from emp group by deptno) t
	join salgrade sg on avg_sal between sg.losal and sg.hisal)
/

