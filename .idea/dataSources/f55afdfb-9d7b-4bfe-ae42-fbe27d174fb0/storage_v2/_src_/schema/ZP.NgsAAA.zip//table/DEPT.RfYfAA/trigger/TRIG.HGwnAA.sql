create trigger TRIG
  after update
  on DEPT
  for each row
  begin
update emp set deptno=:NEW.deptno where deptno=:OLD.deptno;
end;
/

