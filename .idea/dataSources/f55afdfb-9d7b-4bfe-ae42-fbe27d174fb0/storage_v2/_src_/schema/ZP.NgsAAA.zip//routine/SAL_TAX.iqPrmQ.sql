create function sal_tax
	(v_sal number)
	return number
is
begin
    if(v_sal<2000) then
	return 0.10;
    elsif(v_sal<2750) then
	return 0.15;
    else
	return 0.20;
    end if;
end;
/

