create view V$_STU as
  select id,name,age from stu
/

